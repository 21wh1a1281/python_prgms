digit :: Int -> [Int]
digit n
    |n>0 = [(mod n 10)] ++ digit(div n 10)
    |otherwise = []

add_1 :: Int -> Bool
add_1 n = sum([x^length(ns)|x<-ns] ) == n
          where ns = digit n



check :: Int -> [Int] -> Int
check n ns = foldl(\acc x -> acc+x^length(digit n)) 0 ns

add_2 :: Int -> Bool 
add_2 n = check n (digit n) == n



add_3 :: Int -> Bool
add_3 n = (sum $ map (\x  -> x^(length(ns))) (ns)) == n
           where ns = digit n
main = do
    print $ add_1 9474
    print $ add_2 9474
    print $ add_3 9474
